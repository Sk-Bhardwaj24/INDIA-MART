document.querySelector(".signopen").addEventListener("click", function () {
  document.querySelector(".bg-modal").style.display = "flex";
});
document.querySelector(".signopen1").addEventListener("click", function () {
  document.querySelector(".bg-modal").style.display = "flex";
});

document.querySelector(".close").addEventListener("click", function () {
  document.querySelector(".bg-modal").style.display = "none";
});
